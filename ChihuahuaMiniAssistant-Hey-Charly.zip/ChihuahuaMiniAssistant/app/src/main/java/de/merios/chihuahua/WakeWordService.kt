package de.merios.chihuahua

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.os.*
import android.speech.*
import java.util.Locale

/** Experimental wake phrase detection using Android's installed speech recognition provider.
 * This is NOT a dedicated offline wake word engine; availability and battery usage vary.
 */
class WakeWordService : Service(), RecognitionListener {
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var enabled = false
    private var waitingForQuestion = false
    private var screenOn = true
    private var retries = 0
    private val restart = Runnable { listen() }
    private val screenReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                Intent.ACTION_SCREEN_OFF -> { screenOn = false; handler.removeCallbacks(restart); recognizer?.cancel() }
                Intent.ACTION_SCREEN_ON -> { screenOn = true; waitingForQuestion = false; schedule(500) }
            }
        }
    }
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        screenOn = (getSystemService(POWER_SERVICE) as PowerManager).isInteractive
        val filter = IntentFilter().apply { addAction(Intent.ACTION_SCREEN_OFF); addAction(Intent.ACTION_SCREEN_ON) }
        registerReceiver(screenReceiver, filter)
        val channel = NotificationChannel("charly_listening", "Hey Charly", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
    }
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            stopSelf(); return START_NOT_STICKY
        }
        val stop = PendingIntent.getService(this, 5, Intent(this, WakeWordService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val note = Notification.Builder(this, "charly_listening")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Charly hört auf ‚Hey Charly‘")
            .setContentText("Nur bei eingeschaltetem Bildschirm · Zum Beenden tippen")
            .setContentIntent(stop)
            .setOngoing(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(71, note, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(71, note)
        if (!enabled) {
            enabled = true
            if (SpeechRecognizer.isRecognitionAvailable(this)) {
                recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { it.setRecognitionListener(this) }
                schedule(100)
            } else stopSelf()
        }
        return START_NOT_STICKY
    }
    private fun schedule(delay: Long) {
        handler.removeCallbacks(restart)
        if (enabled && screenOn) handler.postDelayed(restart, delay)
    }
    private fun listen() {
        if (!enabled || !screenOn) return
        try {
            val request = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMANY.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            recognizer?.startListening(request)
        } catch (_: Exception) { schedule(2500) }
    }
    private fun process(text: String, final: Boolean) {
        val phrase = text.lowercase(Locale.GERMANY).trim()
        if (!waitingForQuestion) {
            val match = Regex("(?:hey|hei|hi)\\s+charl(?:y|ie|i)", RegexOption.IGNORE_CASE).find(phrase)
            if (match != null) {
                waitingForQuestion = true
                retries = 0
                val rest = text.substring(match.range.last + 1).trim(' ', ',', '.', '!', '?')
                if (rest.isNotEmpty()) { forward(rest); waitingForQuestion = false }
                else if (final) schedule(500)
            }
        } else if (final && phrase.isNotBlank()) {
            if (!phrase.contains("hey charly")) { forward(text); waitingForQuestion = false }
        }
    }
    private fun forward(text: String) {
        try {
            startService(Intent(this, FloatingDogService::class.java).apply {
                action = FloatingDogService.ACTION_VOICE_RESULT
                putExtra(FloatingDogService.EXTRA_SPOKEN, text)
            })
        } catch (_: Exception) { }
    }
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) {}
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onError(error: Int) {
        retries++
        if (waitingForQuestion && retries > 3) waitingForQuestion = false
        // No tight restart loop when the provider is busy or unavailable.
        schedule(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY || error == SpeechRecognizer.ERROR_CLIENT) 3000 else 1200)
    }
    override fun onResults(results: Bundle?) {
        val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
        if (!text.isNullOrBlank()) process(text, true)
        schedule(if (waitingForQuestion) 500 else 900)
    }
    override fun onPartialResults(partialResults: Bundle?) { /* Wait for final result to avoid duplicate requests. */ }
    override fun onEvent(eventType: Int, params: Bundle?) {}
    override fun onDestroy() {
        enabled = false
        handler.removeCallbacks(restart)
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
        try { unregisterReceiver(screenReceiver) } catch (_: Exception) {}
        super.onDestroy()
    }
    companion object { const val ACTION_STOP = "de.merios.chihuahua.STOP_WAKE" }
}
