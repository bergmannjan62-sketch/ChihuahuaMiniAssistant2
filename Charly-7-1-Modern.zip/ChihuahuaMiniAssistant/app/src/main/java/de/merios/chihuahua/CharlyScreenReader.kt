package de.merios.chihuahua

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in: reads only visible accessibility text when the user explicitly asks. */
class CharlyScreenReader : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { current = this }
    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }

    fun visibleText(): String {
        val root = rootInActiveWindow ?: return ""
        val found = LinkedHashSet<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 35 || found.size > 150) return
            if (node.isVisibleToUser && !node.isPassword) {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.take(300)) }
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.take(300)) }
                for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return found.joinToString("\n").take(8000)
    }

    fun control(raw: String, callback: (String) -> Unit) {
        val s = raw.lowercase(java.util.Locale.GERMANY)
        val result = when {
            s.contains("benachrichtigung") -> if (performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)) "Benachrichtigungen geöffnet." else "Benachrichtigungen konnten nicht geöffnet werden."
            s.contains("startbildschirm") || s.contains("home-bildschirm") -> if (performGlobalAction(GLOBAL_ACTION_HOME)) "Startbildschirm geöffnet." else "Startbildschirm konnte nicht geöffnet werden."
            s.contains("zurück") || s.contains("zurueck") -> if (performGlobalAction(GLOBAL_ACTION_BACK)) "Zurückgegangen." else "Zurück konnte nicht ausgeführt werden."
            s.contains("scroll") || s.contains("wisch") -> {
                val down = !s.contains("oben") && !s.contains("hoch")
                val m = resources.displayMetrics
                val path = Path().apply {
                    moveTo(m.widthPixels * 0.5f, m.heightPixels * if (down) 0.75f else 0.3f)
                    lineTo(m.widthPixels * 0.5f, m.heightPixels * if (down) 0.3f else 0.75f)
                }
                val gesture = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, 450)).build()
                if (dispatchGesture(gesture, null, null)) "Scrolle ${if (down) "nach unten" else "nach oben"}." else "Android hat das Scrollen abgelehnt."
            }
            else -> {
                val target = Regex("""(?:tippe|drücke|klicke)\s+(?:bitte\s+)?(?:auf\s+)?(.+)""", RegexOption.IGNORE_CASE).find(raw)?.groupValues?.get(1)?.trim()?.trimEnd('.', '?', '!')
                if (target.isNullOrBlank()) "Bitte nenne eine Schaltfläche, zum Beispiel: Tippe auf Suchen."
                else if (Regex("(?i)(kaufen|bezahlen|bestellen|überweisen|löschen|passwort|pin|bestätigen|freigeben|senden|abschicken|installieren)").containsMatchIn(target)) "Sensible Aktionen musst du selbst bestätigen."
                else {
                    val matches = mutableListOf<android.view.accessibility.AccessibilityNodeInfo>()
                    fun scan(n: android.view.accessibility.AccessibilityNodeInfo?, depth: Int) {
                        if (n == null || depth > 30 || matches.size > 10) return
                        if (n.isVisibleToUser && !n.isPassword) {
                            val label = listOfNotNull(n.text?.toString(), n.contentDescription?.toString()).joinToString(" ").trim()
                            if (label.equals(target, true)) matches.add(n)
                            for (i in 0 until n.childCount) scan(n.getChild(i), depth + 1)
                        }
                    }
                    scan(rootInActiveWindow, 0)
                    if (matches.size != 1) if (matches.isEmpty()) "Schaltfläche $target nicht gefunden." else "Mehrere Treffer für $target. Bitte tippe selbst."
                    else {
                        var node: android.view.accessibility.AccessibilityNodeInfo? = matches.first()
                        while (node != null && !node.isClickable) node = node.parent
                        if (node?.performAction(android.view.accessibility.AccessibilityNodeInfo.ACTION_CLICK) == true) "Auf $target getippt." else "Auf $target konnte nicht getippt werden."
                    }
                }
            }
        }
        callback(result)
    }
    companion object { @Volatile var current: CharlyScreenReader? = null; private set }
}
