package de.merios.chihuahua

import java.util.Locale

object CharlyPhoneControl {
    fun execute(raw: String, callback: (String) -> Unit): Boolean {
        val s = raw.lowercase(Locale.GERMANY).trim()
        val matched = Regex("""^(?:hey charly[, ]*|charly[, ]*)?(?:bitte\s+)?(?:tippe|drücke|klicke|scrolle|scroll|wische|wisch|geh zurück|gehe zurück|zurück|zurueck|geh zum startbildschirm|gehe zum startbildschirm|öffne den startbildschirm|zeige (?:mir )?die benachrichtigungen|öffne (?:die )?benachrichtigungen)""").containsMatchIn(s)
        if (!matched) return false
        val reader = CharlyScreenReader.current
        if (reader == null) callback("Aktiviere Charlys Bedienungshilfe unter Android-Einstellungen → Eingabehilfe → Installierte Apps.")
        else reader.control(raw, callback)
        return true
    }
}
