package de.merios.chihuahua
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.EditText
import android.widget.Toast

object CharlyExtras {
    const val EXTRA_REQUEST = "charly_extra_request"
    fun isMessage(s: String) = s.lowercase().let { (it.contains("whatsapp") || it.contains("nachricht")) && (it.contains("schreib") || it.contains("send") || it.contains("vorbereit") || it.contains("verfass")) }
    fun handle(a: Activity, text: String, reply: (String) -> Unit): Boolean {
        if (isMessage(text)) {
            val draft = Regex("""(?i)(?:dass|:)\s*(.+)""").find(text)?.groupValues?.get(1).orEmpty()
            val edit = EditText(a).apply { setText(draft); hint = "Nachricht eingeben oder prüfen"; minLines = 2 }
            AlertDialog.Builder(a).setTitle("WhatsApp-Nachricht vorbereiten")
                .setMessage("Prüfe den Text. Empfänger und Versand bestätigst du anschließend selbst in WhatsApp.")
                .setView(edit).setNegativeButton("Abbrechen", null)
                .setPositiveButton("WhatsApp öffnen") { _, _ ->
                    val msg = edit.text.toString().trim()
                    if (msg.isBlank()) Toast.makeText(a, "Nachricht ist leer", Toast.LENGTH_SHORT).show()
                    else try { a.startActivity(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg); setPackage("com.whatsapp")
                    }) } catch (_: Exception) { reply("WhatsApp konnte nicht geöffnet werden.") }
                }.show()
            return true
        }
        return false
    }
}
