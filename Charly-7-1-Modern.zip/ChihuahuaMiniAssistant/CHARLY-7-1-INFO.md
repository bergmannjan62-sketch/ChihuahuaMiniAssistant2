Charly 7.1 – UI Refresh
- Modernes kompaktes Chat-Layout mit Sprechblasen, Schnellzugriffen und zentralen Einstellungen.
- App-Icon (Chihuahua) in allen Android-Mipmap-Auflösungen, App-Name Charly.
- Groq openai/gpt-oss-20b unverändert.
- WhatsApp-Vorschau bleibt erhalten; Empfänger und Versand werden in WhatsApp manuell bestätigt.
- Kamera/Vision-Funktion entfernt.
- Sprachdialog-Folgemodus ohne wiederholtes Aktivierungswort ist noch NICHT implementiert.
- Der Build ist nicht auf einem Android-SDK getestet.
- GitHub Workflow im Projekt erwartet entpackte Projektdateien im Repository-Root.
