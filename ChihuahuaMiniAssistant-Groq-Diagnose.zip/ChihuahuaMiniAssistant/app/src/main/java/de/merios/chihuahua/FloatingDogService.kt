package de.merios.chihuahua

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.abs

class FloatingDogService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private val dark = Color.rgb(24, 34, 27)
    private val green = Color.rgb(134, 226, 145)
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dog = TextView(this).apply {
            text = "🐶"; textSize = 40f; gravity = Gravity.CENTER
            background = bg(dark, 32)
            contentDescription = "Chihuahua: tippen zum Chatten, ziehen zum Verschieben"
        }
        val params = WindowManager.LayoutParams(dp(68), dp(68), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(180)
        }
        bubbleParams = params
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        dog.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + e.rawX - touchX).toInt().coerceAtLeast(0)
                    params.y = (startY + e.rawY - touchY).toInt().coerceAtLeast(0)
                    wm.updateViewLayout(dog, params); true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - touchX) < dp(12) && abs(e.rawY - touchY) < dp(12)) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(dog, params)
        bubble = dog
        return START_STICKY
    }
    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(dark)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "🐶 Chihuahua"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val close = Button(this).apply { text = "✕"; setOnClickListener { closePanel() } }
        header.addView(close, LinearLayout.LayoutParams(dp(50), dp(48)))
        container.addView(header)
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun add(who: String, msg: String) {
            val t = TextView(this).apply { text = "$who: $msg"; textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(6), dp(8), dp(6), dp(8)) }
            messages.addView(t)
        }
        add("Chihuahua", "Wuff! Schreib mir hier direkt über deinen Apps. 🐾")
        val scroll = ScrollView(this).apply { addView(messages) }
        container.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "Nachricht …"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 15f }
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val send = Button(this).apply { text = "➤"; setTextColor(Color.BLACK); backgroundTintList = android.content.res.ColorStateList.valueOf(green) }
        send.setOnClickListener {
            val msg = input.text.toString().trim()
            if (msg.isNotEmpty()) {
                add("Du", msg); input.setText("")
                if (GroqAi.hasKey(this)) {
                    add("Chihuahua", "Denke nach …")
                    GroqAi.ask(this, msg) { answer ->
                        if (panel === container) {
                            add("Chihuahua", answer)
                            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                        }
                    }
                } else {
                    val s = msg.lowercase(Locale.GERMANY)
                    val reply = when {
                        s.contains("uhrzeit") || s == "uhr" -> "Es ist ${SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date())} Uhr."
                        s.contains("datum") -> "Heute ist ${SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date())}."
                        s.contains("hallo") || s.contains("hey") -> "Wuff! Schön, dass du da bist! 🐾"
                        s.contains("öffne einstellungen") -> { try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}; "Ich öffne die Einstellungen." }
                        s.contains("öffne youtube") -> { try { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (_: Exception) {}; "Ich öffne YouTube." }
                        else -> "Öffne die Haupt-App und speichere deinen Groq-Schlüssel unter KI-Einstellungen."
                    }
                    add("Chihuahua", reply)
                }
                scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
            }
        }
        row.addView(send, LinearLayout.LayoutParams(dp(58), dp(52)))
        container.addView(row)
        val full = Button(this).apply { text = "🎤 Sprache / ganzen Chat öffnen"; isAllCaps = false; setOnClickListener {
            startActivity(Intent(this@FloatingDogService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } }
        container.addView(full)
        val exit = TextView(this).apply { text = "Schwebemodus beenden"; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4)); setOnClickListener { stopSelf() } }
        container.addView(exit)
        val width = (resources.displayMetrics.widthPixels - dp(28)).coerceAtMost(dp(390))
        val params = WindowManager.LayoutParams(width, dp(370), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(90); softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(container, params); panel = container
    }
    private fun closePanel() { panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }
    override fun onDestroy() { closePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; super.onDestroy() }
}
