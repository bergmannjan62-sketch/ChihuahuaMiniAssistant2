package de.merios.chihuahua

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Local, bounded memory. Explicit memories can be managed in the main app. */
object CharlyMemory {
    private const val PREF = "charly_memory_v1"
    private const val FACTS = "facts"
    private const val HISTORY = "history"
    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun read(c: Context, key: String): JSONArray = try {
        JSONArray(prefs(c).getString(key, "[]"))
    } catch (_: Exception) { JSONArray() }
    private fun write(c: Context, key: String, a: JSONArray) { prefs(c).edit().putString(key, a.toString()).apply() }
    fun facts(c: Context): List<String> = read(c, FACTS).let { a -> (0 until a.length()).map { a.optString(it) }.filter { it.isNotBlank() } }
    fun remember(c: Context, fact: String): String {
        val clean = fact.trim().trimEnd('.', '!', '?').take(300)
        if (clean.length < 3) return "Was soll ich mir merken? Sage zum Beispiel: Merk dir, dass ich Kaffee mag."
        val all = (facts(c).filterNot { it.equals(clean, true) } + clean).takeLast(40)
        write(c, FACTS, JSONArray(all))
        return "Das merke ich mir: $clean."
    }
    fun forget(c: Context, term: String): String {
        val all = facts(c)
        val remaining = all.filterNot { it.contains(term, ignoreCase = true) }
        if (remaining.size == all.size) return "Dazu habe ich keine gespeicherte Erinnerung gefunden."
        write(c, FACTS, JSONArray(remaining))
        return "Ich habe ${all.size - remaining.size} passende Erinnerung(en) gelöscht."
    }
    fun clearFacts(c: Context) { prefs(c).edit().remove(FACTS).apply() }
    fun clearHistory(c: Context) { prefs(c).edit().remove(HISTORY).apply() }
    fun history(c: Context): JSONArray = read(c, HISTORY)
    fun record(c: Context, question: String, answer: String) {
        if (answer.startsWith("Groq HTTP") || answer.startsWith("Groq-Verbindungsfehler") || answer.startsWith("Dein Groq API-Schlüssel") || answer.startsWith("Das kostenlose Groq-Limit")) return
        val old = read(c, HISTORY)
        val next = JSONArray()
        for (i in (old.length() - 15).coerceAtLeast(0) until old.length()) next.put(old.optJSONObject(i))
        next.put(JSONObject().put("role", "user").put("content", question.take(1000)))
        next.put(JSONObject().put("role", "assistant").put("content", answer.take(1500)))
        write(c, HISTORY, next)
    }
    fun command(c: Context, input: String): String? {
        val s = input.trim().replace(Regex("^(hey\\s+charly[,! ]*|charly[,! ]*)", RegexOption.IGNORE_CASE), "").trim()
        val save = Regex("^(?:bitte\\s+)?merk\\s+(?:dir\\s+)?(?:bitte\\s+)?(?:dass\\s+)?(.+)$", RegexOption.IGNORE_CASE).find(s)
        if (save != null) return remember(c, save.groupValues[1])
        val forget = Regex("^(?:vergiss|lösche die erinnerung an)\\s+(.+)$", RegexOption.IGNORE_CASE).find(s)
        if (forget != null) return forget(c, forget.groupValues[1])
        if (s.matches(Regex("(?:was\\s+(?:hast\\s+du\\s+dir|weißt\\s+du\\s+über\\s+mich)\\s+gemerkt|was\\s+weißt\\s+du\\s+über\\s+mich)[?.! ]*", RegexOption.IGNORE_CASE))) {
            return facts(c).takeIf { it.isNotEmpty() }?.joinToString("; ", "Ich habe mir gemerkt: ") ?: "Ich habe noch keine dauerhaften Erinnerungen."
        }
        return null
    }
}
