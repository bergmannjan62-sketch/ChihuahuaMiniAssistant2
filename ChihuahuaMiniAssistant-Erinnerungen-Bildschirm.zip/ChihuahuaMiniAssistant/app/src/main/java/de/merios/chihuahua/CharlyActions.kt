package de.merios.chihuahua

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import java.util.Calendar
import java.util.Locale

/** System clock intents: user can review/modify alarms in the clock app. */
object CharlyActions {
    fun execute(context: Context, raw: String): String? {
        val s = raw.lowercase(Locale.GERMANY).trim()
        val reminder = s.contains("erinnere mich") || s.contains("erinnerung")
        val alarm = s.contains("wecker") || s.contains("weck mich")
        val timer = s.contains("timer")
        if (!reminder && !alarm && !timer) return null
        val relative = Regex("(?:in|für|auf)\\s+(\\d{1,3})\\s*(minuten?|stunden?)").find(s)
        val absolute = Regex("(?:um|auf)\\s+(\\d{1,2})(?:[:.]([0-5]\\d))?\\s*(?:uhr)?").find(s)
        val label = raw.substringAfter(" an ", "").takeIf { it.isNotBlank() } ?: "Charly-Erinnerung"
        return try {
            val intent = when {
                relative != null -> {
                    val n = relative.groupValues[1].toInt()
                    val seconds = n * if (relative.groupValues[2].startsWith("stund")) 3600 else 60
                    Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                }
                absolute != null -> {
                    val hour = absolute.groupValues[1].toInt()
                    val minute = absolute.groupValues[2].ifBlank { "0" }.toInt()
                    if (hour !in 0..23) return "Bitte nenne eine Uhrzeit zwischen 0 und 23 Uhr."
                    Intent(AlarmClock.ACTION_SET_ALARM).putExtra(AlarmClock.EXTRA_HOUR, hour)
                        .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                        .putExtra(AlarmClock.EXTRA_MESSAGE, label)
                }
                else -> return "Sag zum Beispiel: Erinnere mich in 20 Minuten an die Wäsche oder stell einen Wecker um 7 Uhr."
            }
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            "Ich habe die Uhr-App geöffnet. Bitte bestätige dort ${if (relative != null) "den Timer" else "den Wecker"}."
        } catch (e: Exception) { "Ich konnte die Uhr-App nicht öffnen: ${e.javaClass.simpleName}." }
    }
}
