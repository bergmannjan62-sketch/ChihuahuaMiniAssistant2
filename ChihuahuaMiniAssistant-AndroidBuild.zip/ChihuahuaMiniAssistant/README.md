# Chihuahua Mini-Assistent – Android-Prototyp

Dieses Projekt ist ein früher Android-Prototyp (Version 0.1.0), keine fertige 3D-/KI-App. Die Oberfläche enthält Chat-/Sprachfunktionen soweit im Quellcode umgesetzt; der echte animierte 3D-Chihuahua und eine KI-API sind noch nicht integriert.

## APK über GitHub Actions bauen

1. Lade den **Inhalt** dieses Ordners in das Wurzelverzeichnis eines GitHub-Repositorys hoch. Nicht nur diese ZIP-Datei hochladen.
2. Stelle sicher, dass `.github/workflows/android.yml` ebenfalls hochgeladen ist.
3. Öffne auf GitHub den Reiter **Actions**.
4. Wähle **Build Chihuahua Android APK** und tippe auf **Run workflow** (oder warte auf den automatischen Build nach einem Commit).
5. Öffne den abgeschlossenen Lauf und lade unter **Artifacts** `ChihuahuaMiniAssistant-debug-apk` herunter.
6. Entpacke das Artifact und installiere `app-debug.apk` auf Android. Bei Aufforderung erlaube deinem Browser/Dateimanager die Installation unbekannter Apps.

Der APK ist ein Debug-Build zur Erprobung, nicht eine Play-Store-Veröffentlichung.
