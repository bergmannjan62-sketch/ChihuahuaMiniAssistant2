Charly 7.0
- WhatsApp: Nachricht wird in Charly geprüft, dann an WhatsApp zum manuellen Empfänger-Auswählen und Absenden übergeben.
- Bilderkennung: Bildauswahl über Android; Bild wird mit dem hinterlegten Groq-Schlüssel an ein Vision-Modell gesendet.
- Standard-Vision-Modell: meta-llama/llama-4-scout-17b-16e-instruct. Wenn Groq das Modell nicht anbietet, erscheint der API-Fehler.
- Android kann das automatische Öffnen einer Activity aus einem Hintergrunddienst verhindern; dann die Haupt-App öffnen.
- Es wird kein Foto ohne aktive Auswahl übertragen.
