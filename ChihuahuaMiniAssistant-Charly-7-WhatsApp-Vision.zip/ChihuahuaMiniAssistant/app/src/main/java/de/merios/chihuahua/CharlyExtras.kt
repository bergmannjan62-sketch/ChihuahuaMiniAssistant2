package de.merios.chihuahua
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.widget.EditText
import android.widget.Toast

object CharlyExtras {
    const val PHOTO_REQUEST = 713
    const val EXTRA_REQUEST = "charly_extra_request"
    fun isPhoto(s: String) = s.lowercase().let { it.contains("foto") || it.contains("kamera") || it.contains("was ist das für") || it.contains("bild analys") }
    fun isMessage(s: String) = s.lowercase().let { (it.contains("whatsapp") || it.contains("nachricht")) && (it.contains("schreib") || it.contains("send") || it.contains("vorbereit") || it.contains("verfass")) }
    fun handle(a: Activity, text: String, reply: (String) -> Unit): Boolean {
        if (isPhoto(text)) {
            try { a.startActivityForResult(Intent.createChooser(Intent(Intent.ACTION_GET_CONTENT).apply { type = "image/*"; addCategory(Intent.CATEGORY_OPENABLE) }, "Foto auswählen"), PHOTO_REQUEST) }
            catch (e: Exception) { reply("Bildauswahl fehlgeschlagen: ${e.message}") }
            return true
        }
        if (isMessage(text)) {
            val draft = Regex("""(?i)(?:dass|:)\s*(.+)""").find(text)?.groupValues?.get(1).orEmpty()
            val edit = EditText(a).apply { setText(draft); hint = "Nachricht eingeben oder prüfen"; minLines = 2 }
            AlertDialog.Builder(a).setTitle("WhatsApp-Nachricht vorbereiten")
                .setMessage("Prüfe den Text. Empfänger und Versand bestätigst du anschließend selbst in WhatsApp.")
                .setView(edit).setNegativeButton("Abbrechen", null)
                .setPositiveButton("WhatsApp öffnen") { _, _ ->
                    val msg = edit.text.toString().trim()
                    if (msg.isBlank()) Toast.makeText(a, "Nachricht ist leer", Toast.LENGTH_SHORT).show()
                    else try { a.startActivity(Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"; putExtra(Intent.EXTRA_TEXT, msg); setPackage("com.whatsapp")
                    }) } catch (_: Exception) { reply("WhatsApp konnte nicht geöffnet werden.") }
                }.show()
            return true
        }
        return false
    }
}
