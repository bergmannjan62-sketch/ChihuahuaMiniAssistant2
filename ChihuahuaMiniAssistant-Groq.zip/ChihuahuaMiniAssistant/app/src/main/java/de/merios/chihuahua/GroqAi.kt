package de.merios.chihuahua

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object GroqAi {
    private val executor = Executors.newSingleThreadExecutor()
    private const val PREF = "chihuahua_ai"
    private const val KEY = "groq_key"
    fun saveKey(context: Context, key: String) {
        context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(KEY, key.trim()).apply()
    }
    fun hasKey(context: Context): Boolean = !context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "").isNullOrBlank()
    fun ask(context: Context, question: String, done: (String) -> Unit) {
        val key = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(KEY, "") ?: ""
        if (key.isBlank()) { done("Bitte zuerst deinen Groq API-Schlüssel in der Haupt-App unter KI-Einstellungen speichern."); return }
        val main = android.os.Handler(android.os.Looper.getMainLooper())
        executor.execute {
            val result = try {
                val url = URL("https://api.groq.com/openai/v1/chat/completions")
                val conn = (url.openConnection() as HttpURLConnection).apply {
                    requestMethod = "POST"
                    connectTimeout = 15000
                    readTimeout = 30000
                    doOutput = true
                    setRequestProperty("Authorization", "Bearer $key")
                    setRequestProperty("Content-Type", "application/json; charset=utf-8")
                }
                try {
                    val messages = JSONArray()
                        .put(JSONObject().put("role", "system").put("content", "Du bist Chihuahua, ein freundlicher, hilfreicher kleiner virtueller Hund auf einem Android-Smartphone. Antworte auf Deutsch, natürlich, präzise und eher kurz. Behaupte nicht, Apps oder Systeme gesteuert zu haben, wenn du es nicht getan hast."))
                        .put(JSONObject().put("role", "user").put("content", question))
                    val payload = JSONObject().put("model", "llama-3.1-8b-instant").put("messages", messages).put("temperature", 0.7).toString()
                    conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
                    val code = conn.responseCode
                    val raw = (if (code in 200..299) conn.inputStream else conn.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
                    if (code in 200..299) JSONObject(raw).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                    else when (code) {
                        401 -> "Dein Groq API-Schlüssel ist ungültig. Bitte prüfe ihn in den KI-Einstellungen."
                        429 -> "Das kostenlose Groq-Limit ist gerade erreicht. Bitte versuche es später erneut."
                        else -> "Groq meldet HTTP $code. Bitte versuche es später erneut."
                    }
                } finally { conn.disconnect() }
            } catch (_: Exception) { "Ich konnte Groq gerade nicht erreichen. Bitte prüfe deine Internetverbindung." }
            main.post { done(result) }
        }
    }
}
