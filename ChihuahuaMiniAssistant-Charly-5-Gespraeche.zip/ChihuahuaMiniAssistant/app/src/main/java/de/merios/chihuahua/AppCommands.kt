package de.merios.chihuahua

import android.content.Context
import android.content.Intent
import android.provider.Settings
import java.util.Locale

/** Explicit, safe voice commands: open a launcher app or Android Settings only. */
object AppCommands {
    fun execute(context: Context, spoken: String): String? {
        val normalized = spoken.lowercase(Locale.GERMANY)
            .replace(Regex("[!?.,:;]+"), " ").replace(Regex("\\s+"), " ").trim()
        val match = Regex("^(?:bitte )?(?:öffne|oeffne|starte|öffnen|oeffnen|starten|mach) (?:mir )?(?:die |das |den )?(.+?)(?: bitte)?$").matchEntire(normalized)
            ?: return null
        val name = match.groupValues[1].trim()
        if (name == "einstellungen" || name == "handyeinstellungen" || name == "handy einstellungen") {
            return launch(context, Intent(Settings.ACTION_SETTINGS), "Einstellungen")
        }
        val aliases = mapOf(
            "whatsapp" to "com.whatsapp", "youtube" to "com.google.android.youtube",
            "spotify" to "com.spotify.music", "kamera" to "com.sec.android.app.camera",
            "google maps" to "com.google.android.apps.maps", "maps" to "com.google.android.apps.maps",
            "chrome" to "com.android.chrome", "gmail" to "com.google.android.gm",
            "play store" to "com.android.vending", "playstore" to "com.android.vending",
            "telefon" to "com.samsung.android.dialer", "galerie" to "com.sec.android.gallery3d"
        )
        val pm = context.packageManager
        val launcherQuery = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val candidates = pm.queryIntentActivities(launcherQuery, 0)
        val knownPackage = aliases[name]
        val selected = if (knownPackage != null) {
            candidates.firstOrNull { it.activityInfo.packageName == knownPackage }
                ?: candidates.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.GERMANY) == name }
        } else {
            candidates.firstOrNull { it.loadLabel(pm).toString().lowercase(Locale.GERMANY) == name }
        }
        if (selected == null) return "Ich finde die App $name nicht auf deinem Handy."
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            .setClassName(selected.activityInfo.packageName, selected.activityInfo.name)
        return launch(context, intent, selected.loadLabel(pm).toString())
    }

    private fun launch(context: Context, intent: Intent, title: String): String {
        return try {
            context.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Ich öffne $title."
        } catch (_: Exception) {
            "Ich konnte $title nicht öffnen. Bitte starte die App einmal selbst."
        }
    }
}
