package de.merios.chihuahua

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import java.util.Locale

/** Starts the system speech recognition UI and returns recognized text to the overlay service. */
class VoiceCaptureActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (savedInstanceState == null) {
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.GERMANY.toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_PROMPT, "Sprich mit deinem Chihuahua 🐶")
            }
            try {
                @Suppress("DEPRECATION")
                startActivityForResult(intent, 501)
            } catch (_: ActivityNotFoundException) {
                Toast.makeText(this, "Keine Spracherkennung installiert.", Toast.LENGTH_LONG).show()
                finish()
            } catch (_: Exception) {
                Toast.makeText(this, "Spracherkennung konnte nicht starten.", Toast.LENGTH_LONG).show()
                finish()
            }
        }
    }

    @Deprecated("Used for system recognition activity compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 501 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) {
                startService(Intent(this, FloatingDogService::class.java).apply {
                    action = FloatingDogService.ACTION_VOICE_RESULT
                    putExtra(FloatingDogService.EXTRA_SPOKEN, text)
                })
            }
        }
        finish()
    }
}
