package de.merios.chihuahua

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Opt-in: reads only visible accessibility text when the user explicitly asks. */
class CharlyScreenReader : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onServiceConnected() { current = this }
    override fun onDestroy() { if (current === this) current = null; super.onDestroy() }

    fun visibleText(): String {
        val root = rootInActiveWindow ?: return ""
        val found = LinkedHashSet<String>()
        fun walk(node: AccessibilityNodeInfo?, depth: Int) {
            if (node == null || depth > 35 || found.size > 150) return
            if (node.isVisibleToUser && !node.isPassword) {
                node.text?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.take(300)) }
                node.contentDescription?.toString()?.trim()?.takeIf { it.isNotEmpty() }?.let { found.add(it.take(300)) }
                for (i in 0 until node.childCount) walk(node.getChild(i), depth + 1)
            }
        }
        walk(root, 0)
        return found.joinToString("\n").take(8000)
    }
    companion object { @Volatile var current: CharlyScreenReader? = null; private set }
}
