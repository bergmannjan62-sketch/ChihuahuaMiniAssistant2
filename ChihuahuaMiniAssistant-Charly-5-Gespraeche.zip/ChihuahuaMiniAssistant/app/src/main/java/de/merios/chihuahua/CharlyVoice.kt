package de.merios.chihuahua

import android.content.Context
import android.speech.tts.TextToSpeech
import java.util.Locale

object CharlyVoice {
    private const val PREFS = "charly_voice"
    fun apply(context: Context, tts: TextToSpeech) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        tts.language = Locale.GERMANY
        val selected = prefs.getString("voice", null)
        val germanVoices = tts.voices.orEmpty().filter { it.locale.language == "de" }
        val voice = germanVoices.firstOrNull { it.name == selected }
        if (voice != null) tts.voice = voice
        tts.setSpeechRate(prefs.getFloat("speed", 0.94f))
        tts.setPitch(prefs.getFloat("pitch", 1.0f))
    }
    fun save(context: Context, name: String?, speed: Float) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString("voice", name).putFloat("speed", speed).apply()
    }
    fun speed(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getFloat("speed", 0.94f)
    fun selected(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("voice", null)
}
