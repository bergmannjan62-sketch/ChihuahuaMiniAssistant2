Animierter Chihuahua: Blinzeln, Schwanzwedeln und leichtes Wippen. Overlay-Chat, Ziehen und Groq bleiben erhalten. Das Groq-Modell wird im GitHub Workflow weiterhin auf openai/gpt-oss-20b umgestellt.
