# Charly 5.0 – natürlichere Gespräche

- Nutzt die letzten bis zu 12 Gesprächsrunden als Kontext für Anschlussfragen.
- Reagiert natürlicher, mit gelegentlichen sinnvollen Rückfragen.
- Unterscheidet explizit gespeicherte Fakten von kurzzeitigem Gesprächskontext.
- Der lokale Gesprächsverlauf kann in der App wie bisher gelöscht werden.
- API-Anfragen werden weiterhin an Groq gesendet; der Kontext wird dabei mit übertragen.
- Keine neue Berechtigung erforderlich. Bestehende Animationen und Gerätefunktionen bleiben erhalten.
