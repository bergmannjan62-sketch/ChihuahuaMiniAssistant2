# Chihuahua mit Groq

APK über GitHub Actions erstellen. Haupt-App öffnen → Groq KI-Einstellungen → eigenen Groq API-Schlüssel eingeben. Der Schlüssel wird lokal in den App-Einstellungen gespeichert und nicht in das Repository eingebaut. Für private Tests geeignet; für eine öffentlich verteilte App sollte ein eigener Server/Proxy den API-Schlüssel verwalten. Groq benötigt Internet und hat kostenlose Nutzungslimits. Der bisherige Schwebemodus bleibt erhalten.
