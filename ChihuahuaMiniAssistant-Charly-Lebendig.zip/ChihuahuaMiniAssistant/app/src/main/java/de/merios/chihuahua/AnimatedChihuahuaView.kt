package de.merios.chihuahua

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.os.SystemClock
import android.view.View
import kotlin.math.sin

/** Animierter, selbst gezeichneter Chihuahua ohne zusätzliche Bilddateien. */
class AnimatedChihuahuaView(context: Context) : View(context) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var speaking = false
    private var excitedUntil = 0L
    private var jumpUntil = 0L
    private var lastInteraction = SystemClock.uptimeMillis()
    fun celebrate() { lastInteraction = SystemClock.uptimeMillis(); excitedUntil = lastInteraction + 2200L; invalidate() }
    fun jump() { lastInteraction = SystemClock.uptimeMillis(); jumpUntil = lastInteraction + 650L; invalidate() }
    fun wakeUp() { lastInteraction = SystemClock.uptimeMillis(); invalidate() }
    fun isSleeping(): Boolean = !speaking && SystemClock.uptimeMillis() - lastInteraction > 120000L
    fun setSpeaking(value: Boolean) { speaking = value; if (value) wakeUp(); postInvalidateOnAnimation() }
    private val start = SystemClock.uptimeMillis()
    private fun color(c: Int) { paint.color = c; paint.style = Paint.Style.FILL }
    private fun oval(c: Canvas, x: Float, y: Float, rx: Float, ry: Float, col: Int) {
        color(col); c.drawOval(x-rx,y-ry,x+rx,y+ry,paint)
    }
    private fun triangle(c: Canvas, x1:Float,y1:Float,x2:Float,y2:Float,x3:Float,y3:Float,col:Int) {
        color(col); val path=Path().apply { moveTo(x1,y1);lineTo(x2,y2);lineTo(x3,y3);close() }; c.drawPath(path,paint)
    }
    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val elapsed = (SystemClock.uptimeMillis()-start).toFloat()
        val now = SystemClock.uptimeMillis()
        val sleeping = isSleeping()
        val excited = now < excitedUntil
        val wave = sin(elapsed / (if (excited) 85f else 210f)) * (if (excited) 13f else 7f)
        val bounce = sin(elapsed / 480f) * 1.8f
        val blink = (elapsed.toLong() % 4200L) in 3900L..4030L
        canvas.save()
        canvas.scale(width / 100f, height / 100f)
        // Runde, transparente Spielfläche
        oval(canvas,50f,51f,49f,49f,Color.rgb(26,39,31))
        val jumpProgress = ((jumpUntil - now).toFloat() / 650f).coerceIn(0f, 1f)
        val jumpHeight = if (jumpProgress > 0f) kotlin.math.sin((1f - jumpProgress) * Math.PI).toFloat() * 13f else 0f
        canvas.translate(0f, if (sleeping) sin(elapsed / 900f) * 0.8f else bounce - jumpHeight)
        // Schwanz hinter dem Körper, schwingt sanft
        oval(canvas,77f+wave,66f,9f,5f,Color.rgb(184,111,54))
        oval(canvas,50f,76f,25f,17f,Color.rgb(200,132,73))
        oval(canvas,50f,81f,13f,11f,Color.rgb(246,215,166))
        // Große Chihuahua-Ohren
        triangle(canvas,20f,48f,16f,8f,45f,30f,Color.rgb(191,116,60))
        triangle(canvas,80f,48f,84f,8f,55f,30f,Color.rgb(191,116,60))
        triangle(canvas,25f,38f,21f,17f,41f,32f,Color.rgb(238,161,157))
        triangle(canvas,75f,38f,79f,17f,59f,32f,Color.rgb(238,161,157))
        oval(canvas,50f,49f,32f,29f,Color.rgb(215,150,87))
        oval(canvas,50f,62f,19f,13f,Color.rgb(250,224,187))
        // Augen mit regelmäßigem Blinzeln
        if (blink || sleeping) {
            oval(canvas,38f,47f,6f,1.5f,Color.rgb(49,31,25))
            oval(canvas,62f,47f,6f,1.5f,Color.rgb(49,31,25))
        } else {
            oval(canvas,38f,46f,6.5f,8f,Color.rgb(39,26,23))
            oval(canvas,62f,46f,6.5f,8f,Color.rgb(39,26,23))
            oval(canvas,40f,43f,2.1f,2.5f,Color.WHITE)
            oval(canvas,64f,43f,2.1f,2.5f,Color.WHITE)
        }
        oval(canvas,50f,60f,5.8f,4f,Color.rgb(55,35,34))
        // Beim Vorlesen bewegt sich der Mund rhythmisch.
        if (speaking) {
            val open = 2.5f + (sin(elapsed / 95f) + 1f) * 3.8f
            oval(canvas, 50f, 68f, 6.5f, open, Color.rgb(76, 28, 37))
            oval(canvas, 50f, 69f + open * 0.35f, 3.2f, 1.5f, Color.rgb(236, 122, 138))
        } else {
            color(Color.rgb(72,41,36)); paint.style=Paint.Style.STROKE;paint.strokeWidth=1.8f
            canvas.drawArc(44f,59f,56f,70f,10f,160f,false,paint)
            paint.style=Paint.Style.FILL
        }
        if (sleeping) {
            color(Color.rgb(231, 240, 229))
            paint.textSize = 12f
            paint.typeface = android.graphics.Typeface.DEFAULT_BOLD
            canvas.drawText("Zzz", 66f, 18f, paint)
        }
        canvas.restore()
        postInvalidateDelayed(55L)
    }
}
