package de.merios.chihuahua

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.*
import java.util.Locale
import java.text.SimpleDateFormat
import java.util.Date
import kotlin.math.abs

class FloatingDogService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var dogView: AnimatedChihuahuaView? = null
    private val ui = Handler(Looper.getMainLooper())
    private var panel: View? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var voiceEnabled = true
    private var messageReceiver: ((String) -> Unit)? = null
    private var bubbleParams: WindowManager.LayoutParams? = null
    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Int = 18) = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius).toFloat() }
    private val dark = Color.rgb(24, 34, 27)
    private val green = Color.rgb(134, 226, 145)
    override fun onBind(intent: Intent?): IBinder? = null
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "de.merios.chihuahua.UPDATE_VOICE") {
            tts?.let { if (ttsReady) CharlyVoice.apply(this, it) }
            return START_STICKY
        }
        if (intent?.action == ACTION_VOICE_RESULT) {
            val spoken = intent.getStringExtra(EXTRA_SPOKEN).orEmpty().trim()
            if (spoken.isNotBlank()) {
                if (panel != null) {
                    messageReceiver?.invoke(spoken)
                } else {
                    answerWithoutChat(spoken)
                }
            }
            return START_STICKY
        }
        if (bubble != null) return START_STICKY
        tts = TextToSpeech(this) { status ->
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = tts?.setLanguage(Locale.GERMANY) != TextToSpeech.LANG_MISSING_DATA
                tts?.let { CharlyVoice.apply(this, it) }
            }
        }
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { ui.post { dogView?.setSpeaking(true) } }
            override fun onDone(utteranceId: String?) { ui.post { dogView?.setSpeaking(false); resumeWake() } }
            @Deprecated("Android TTS callback")
            override fun onError(utteranceId: String?) { ui.post { dogView?.setSpeaking(false); resumeWake() } }
        })
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dog = AnimatedChihuahuaView(this).apply {
            contentDescription = "Animierter Chihuahua: tippen zum Chatten, ziehen zum Verschieben"
        }
        val params = WindowManager.LayoutParams(dp(68), dp(68), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START; x = dp(16); y = dp(180)
        }
        bubbleParams = params
        var startX = 0; var startY = 0; var touchX = 0f; var touchY = 0f
        dog.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startX = params.x; startY = params.y; touchX = e.rawX; touchY = e.rawY; true }
                MotionEvent.ACTION_MOVE -> {
                    params.x = (startX + e.rawX - touchX).toInt().coerceAtLeast(0)
                    params.y = (startY + e.rawY - touchY).toInt().coerceAtLeast(0)
                    wm.updateViewLayout(dog, params); true
                }
                MotionEvent.ACTION_UP -> {
                    if (abs(e.rawX - touchX) < dp(12) && abs(e.rawY - touchY) < dp(12)) togglePanel()
                    true
                }
                else -> false
            }
        }
        wm.addView(dog, params)
        bubble = dog
        dogView = dog
        return START_STICKY
    }
    private fun togglePanel() {
        if (panel != null) { closePanel(); return }
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(dark)
        }
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        val title = TextView(this).apply { text = "🐶 Chihuahua"; textSize = 19f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.WHITE) }
        header.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        val close = Button(this).apply { text = "✕"; setOnClickListener { closePanel() } }
        header.addView(close, LinearLayout.LayoutParams(dp(50), dp(48)))
        container.addView(header)
        val messages = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun add(who: String, msg: String) {
            val t = TextView(this).apply { text = "$who: $msg"; textSize = 14f; setTextColor(Color.WHITE); setPadding(dp(6), dp(8), dp(6), dp(8)) }
            messages.addView(t)
        }
        add("Chihuahua", "Wuff! Schreib mir hier direkt über deinen Apps. 🐾")
        val scroll = ScrollView(this).apply { addView(messages) }
        container.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val input = EditText(this).apply { hint = "Nachricht …"; setSingleLine(true); setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 15f }
        row.addView(input, LinearLayout.LayoutParams(0, dp(52), 1f))
        val mic = Button(this).apply {
            text = "🎤"; isAllCaps = false
            contentDescription = "Mit Chihuahua sprechen"
            setOnClickListener {
                try {
                    startActivity(Intent(this@FloatingDogService, VoiceCaptureActivity::class.java)
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                } catch (_: Exception) { add("Chihuahua", "Spracherkennung konnte nicht geöffnet werden.") }
            }
        }
        row.addView(mic, LinearLayout.LayoutParams(dp(55), dp(52)))
        val send = Button(this).apply { text = "➤"; setTextColor(Color.BLACK); backgroundTintList = android.content.res.ColorStateList.valueOf(green) }
        fun submit(msg: String) {
            if (msg.isBlank()) return
            add("Du", msg); input.setText("")
            val commandReply = CharlyMemory.command(this, msg) ?: AppCommands.execute(this, msg)
            if (commandReply != null) {
                add("Chihuahua", commandReply)
                speak(commandReply)
            } else if (GroqAi.hasKey(this)) {
                add("Chihuahua", "Denke nach …")
                GroqAi.ask(this, msg) { answer ->
                    if (panel === container) {
                        add("Chihuahua", answer)
                        speak(answer)
                        scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
                    }
                }
            } else {
                val lower = msg.lowercase(Locale.GERMANY)
                val reply = when {
                    lower.contains("uhrzeit") || lower == "uhr" -> "Es ist ${SimpleDateFormat("HH:mm", Locale.GERMANY).format(Date())} Uhr."
                    lower.contains("datum") -> "Heute ist ${SimpleDateFormat("dd.MM.yyyy", Locale.GERMANY).format(Date())}."
                    lower.contains("hallo") || lower.contains("hey") -> "Wuff! Schön, dass du da bist! 🐾"
                    else -> "Öffne die Haupt-App und speichere deinen Groq-Schlüssel unter KI-Einstellungen."
                }
                add("Chihuahua", reply)
                speak(reply)
            }
            scroll.post { scroll.fullScroll(View.FOCUS_DOWN) }
        }
        messageReceiver = { spoken -> submit(spoken) }
        send.setOnClickListener { submit(input.text.toString().trim()) }
        row.addView(send, LinearLayout.LayoutParams(dp(58), dp(52)))
        container.addView(row)
        val full = Button(this).apply { text = "Ganzen Chat öffnen"; isAllCaps = false; setOnClickListener {
            startActivity(Intent(this@FloatingDogService, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP))
        } }
        container.addView(full)
        val exit = TextView(this).apply { text = "Schwebemodus beenden"; setTextColor(green); gravity = Gravity.CENTER; setPadding(0, dp(12), 0, dp(4)); setOnClickListener { stopSelf() } }
        container.addView(exit)
        val width = (resources.displayMetrics.widthPixels - dp(28)).coerceAtMost(dp(390))
        val params = WindowManager.LayoutParams(width, dp(370), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = dp(90); softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(container, params); panel = container
    }
    private fun resumeWake() {
        try { startService(Intent(this, WakeWordService::class.java).setAction(WakeWordService.ACTION_RESUME)) } catch (_: Exception) {}
    }
    private fun answerWithoutChat(question: String) {
        val commandReply = CharlyMemory.command(this, question) ?: AppCommands.execute(this, question)
        if (commandReply != null) {
            speak(commandReply)
            return
        }
        if (!GroqAi.hasKey(this)) {
            speak("Bitte hinterlege zuerst deinen Groq-Schlüssel in den Einstellungen.")
            return
        }
        GroqAi.ask(this, question) { answer ->
            // Kein Chatfenster öffnen: nur die Figur spricht.
            speak(answer)
        }
    }
    private fun speak(answer: String) {
        if (ttsReady && !answer.startsWith("Groq HTTP") && !answer.startsWith("Groq-Verbindungsfehler")) {
            dogView?.setSpeaking(true)
            val result = tts?.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "chihuahua-overlay-reply")
            if (result != TextToSpeech.SUCCESS) { dogView?.setSpeaking(false); resumeWake() }
        }
    }
    private fun closePanel() { messageReceiver = null; panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }; panel = null }
    override fun onDestroy() { dogView?.setSpeaking(false); tts?.stop(); tts?.shutdown(); closePanel(); bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }; bubble = null; super.onDestroy() }
    companion object {
        const val ACTION_VOICE_RESULT = "de.merios.chihuahua.VOICE_RESULT"
        const val EXTRA_SPOKEN = "spoken_text"
    }
}
